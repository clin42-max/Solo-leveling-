
export type HunterRank = 'E' | 'D' | 'C' | 'B' | 'A' | 'S' | 'S+';

export interface Stats {
  STR: number; // Strength
  AGI: number; // Agility
  INT: number; // Intelligence
  STA: number; // Stamina
  PER: number; // Perception
  MAG: number; // Magic Potential
}

export interface Hunter {
  id: string;
  name: string;
  level: number;
  xp: number;
  xpToNext: number;
  rank: HunterRank;
  totalPower: number;
  stats: Stats;
  awakened: boolean;
}

export type QuestType = 'Physical' | 'Cognitive' | 'Social' | 'Creative' | 'Recovery';
export type QuestDifficulty = 1 | 2 | 3 | 4 | 5;

export interface Quest {
  id: string;
  title: string;
  description: string;
  type: QuestType;
  difficulty: QuestDifficulty;
  xpReward: number;
  statRewards: Partial<Stats>;
  completed: boolean;
  dailyReset: boolean;
}

export interface QuestHistory {
  questId: string;
  questTitle: string;
  completedAt: Date;
  xpGained: number;
  statsGained: Partial<Stats>;
}
