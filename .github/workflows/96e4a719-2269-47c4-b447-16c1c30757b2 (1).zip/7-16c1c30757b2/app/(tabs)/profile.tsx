
import React from 'react';
import { View, Text, StyleSheet, ScrollView, Platform } from 'react-native';
import { colors } from '@/styles/commonStyles';
import { useHunter } from '@/hooks/useHunter';
import RankBadge from '@/components/RankBadge';
import { IconSymbol } from '@/components/IconSymbol';

export default function ProfileScreen() {
  const { hunter, history } = useHunter();

  if (!hunter) {
    return (
      <View style={styles.emptyContainer}>
        <IconSymbol name="person.crop.circle.badge.questionmark" size={60} color={colors.textSecondary} />
        <Text style={styles.emptyText}>No hunter profile found</Text>
        <Text style={styles.emptySubtext}>Complete awakening to create your profile</Text>
      </View>
    );
  }

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={[
        styles.contentContainer,
        Platform.OS !== 'ios' && styles.contentContainerWithTabBar,
      ]}
    >
      {/* Profile Header */}
      <View style={styles.profileCard}>
        <View style={styles.profileHeader}>
          <IconSymbol name="person.circle.fill" size={80} color={colors.primary} />
          <View style={styles.profileInfo}>
            <Text style={styles.hunterName}>{hunter.name}</Text>
            <Text style={styles.hunterTitle}>Level {hunter.level} Hunter</Text>
          </View>
          <RankBadge rank={hunter.rank} size="medium" />
        </View>
      </View>

      {/* Stats Summary */}
      <View style={styles.summaryCard}>
        <Text style={styles.sectionTitle}>Hunter Statistics</Text>
        
        <View style={styles.summaryGrid}>
          <View style={styles.summaryItem}>
            <IconSymbol name="bolt.fill" size={24} color={colors.primary} />
            <Text style={styles.summaryValue}>{hunter.totalPower.toFixed(1)}</Text>
            <Text style={styles.summaryLabel}>Total Power</Text>
          </View>
          
          <View style={styles.summaryItem}>
            <IconSymbol name="arrow.up.circle.fill" size={24} color={colors.secondary} />
            <Text style={styles.summaryValue}>{hunter.level}</Text>
            <Text style={styles.summaryLabel}>Level</Text>
          </View>
          
          <View style={styles.summaryItem}>
            <IconSymbol name="star.fill" size={24} color={colors.accent} />
            <Text style={styles.summaryValue}>{hunter.xp}</Text>
            <Text style={styles.summaryLabel}>Total XP</Text>
          </View>
        </View>
      </View>

      {/* Detailed Stats */}
      <View style={styles.detailsCard}>
        <Text style={styles.sectionTitle}>Detailed Stats</Text>
        
        <View style={styles.statRow}>
          <View style={styles.statItem}>
            <View style={[styles.statDot, { backgroundColor: colors.str }]} />
            <Text style={styles.statLabel}>STR</Text>
          </View>
          <Text style={styles.statValue}>{hunter.stats.STR}</Text>
        </View>
        
        <View style={styles.statRow}>
          <View style={styles.statItem}>
            <View style={[styles.statDot, { backgroundColor: colors.agi }]} />
            <Text style={styles.statLabel}>AGI</Text>
          </View>
          <Text style={styles.statValue}>{hunter.stats.AGI}</Text>
        </View>
        
        <View style={styles.statRow}>
          <View style={styles.statItem}>
            <View style={[styles.statDot, { backgroundColor: colors.int }]} />
            <Text style={styles.statLabel}>INT</Text>
          </View>
          <Text style={styles.statValue}>{hunter.stats.INT}</Text>
        </View>
        
        <View style={styles.statRow}>
          <View style={styles.statItem}>
            <View style={[styles.statDot, { backgroundColor: colors.sta }]} />
            <Text style={styles.statLabel}>STA</Text>
          </View>
          <Text style={styles.statValue}>{hunter.stats.STA}</Text>
        </View>
        
        <View style={styles.statRow}>
          <View style={styles.statItem}>
            <View style={[styles.statDot, { backgroundColor: colors.per }]} />
            <Text style={styles.statLabel}>PER</Text>
          </View>
          <Text style={styles.statValue}>{hunter.stats.PER}</Text>
        </View>
        
        <View style={styles.statRow}>
          <View style={styles.statItem}>
            <View style={[styles.statDot, { backgroundColor: colors.mag }]} />
            <Text style={styles.statLabel}>MAG</Text>
          </View>
          <Text style={styles.statValue}>{hunter.stats.MAG}</Text>
        </View>
      </View>

      {/* Quest History */}
      <View style={styles.historyCard}>
        <Text style={styles.sectionTitle}>Recent Quest History</Text>
        
        {history.length === 0 ? (
          <View style={styles.emptyHistory}>
            <IconSymbol name="clock" size={32} color={colors.textSecondary} />
            <Text style={styles.emptyHistoryText}>No quest history yet</Text>
            <Text style={styles.emptyHistorySubtext}>
              Complete quests to see your progress here
            </Text>
          </View>
        ) : (
          history.slice(0, 10).map((entry, index) => (
            <View key={`${entry.questId}-${index}`} style={styles.historyItem}>
              <View style={styles.historyIcon}>
                <IconSymbol name="checkmark.circle.fill" size={20} color={colors.secondary} />
              </View>
              <View style={styles.historyContent}>
                <Text style={styles.historyTitle}>{entry.questTitle}</Text>
                <Text style={styles.historyDate}>
                  {new Date(entry.completedAt).toLocaleDateString()}
                </Text>
              </View>
              <Text style={styles.historyXP}>+{entry.xpGained} XP</Text>
            </View>
          ))
        )}
      </View>

      {/* Info Card */}
      <View style={styles.infoCard}>
        <IconSymbol name="info.circle.fill" size={24} color={colors.primary} />
        <Text style={styles.infoText}>
          Your hunter profile tracks all your progress, stats, and achievements. Keep completing quests to grow stronger!
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  contentContainer: {
    padding: 16,
  },
  contentContainerWithTabBar: {
    paddingBottom: 100,
  },
  emptyContainer: {
    flex: 1,
    backgroundColor: colors.background,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginTop: 16,
  },
  emptySubtext: {
    fontSize: 14,
    color: colors.textSecondary,
    marginTop: 8,
    textAlign: 'center',
  },
  profileCard: {
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.1)',
    elevation: 4,
  },
  profileHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  profileInfo: {
    flex: 1,
  },
  hunterName: {
    fontSize: 24,
    fontWeight: '900',
    color: colors.text,
    marginBottom: 4,
  },
  hunterTitle: {
    fontSize: 14,
    color: colors.textSecondary,
    fontWeight: '600',
  },
  summaryCard: {
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.1)',
    elevation: 4,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '800',
    color: colors.text,
    marginBottom: 16,
  },
  summaryGrid: {
    flexDirection: 'row',
    gap: 12,
  },
  summaryItem: {
    flex: 1,
    backgroundColor: colors.background,
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  summaryValue: {
    fontSize: 24,
    fontWeight: '900',
    color: colors.text,
    marginTop: 8,
  },
  summaryLabel: {
    fontSize: 12,
    color: colors.textSecondary,
    marginTop: 4,
    fontWeight: '600',
  },
  detailsCard: {
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.1)',
    elevation: 4,
  },
  statRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.background,
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  statDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
  },
  statLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
  },
  statValue: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.text,
  },
  historyCard: {
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.1)',
    elevation: 4,
  },
  emptyHistory: {
    alignItems: 'center',
    paddingVertical: 20,
  },
  emptyHistoryText: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginTop: 12,
  },
  emptyHistorySubtext: {
    fontSize: 14,
    color: colors.textSecondary,
    marginTop: 4,
    textAlign: 'center',
  },
  historyItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.background,
  },
  historyIcon: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: colors.background,
    justifyContent: 'center',
    alignItems: 'center',
  },
  historyContent: {
    flex: 1,
  },
  historyTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 2,
  },
  historyDate: {
    fontSize: 12,
    color: colors.textSecondary,
  },
  historyXP: {
    fontSize: 14,
    fontWeight: '700',
    color: colors.primary,
  },
  infoCard: {
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 20,
    flexDirection: 'row',
    gap: 12,
    alignItems: 'flex-start',
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.1)',
    elevation: 4,
  },
  infoText: {
    flex: 1,
    fontSize: 14,
    color: colors.textSecondary,
    lineHeight: 20,
  },
});
