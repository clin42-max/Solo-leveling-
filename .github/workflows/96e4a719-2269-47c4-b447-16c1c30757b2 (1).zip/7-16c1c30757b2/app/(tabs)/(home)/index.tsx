
import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, Platform, Pressable, Alert } from 'react-native';
import { Stack } from 'expo-router';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { colors } from '@/styles/commonStyles';
import { useHunter } from '@/hooks/useHunter';
import StatBar from '@/components/StatBar';
import RankBadge from '@/components/RankBadge';
import BlackOrb from '@/components/BlackOrb';
import AwakeningModal from '@/components/AwakeningModal';
import { IconSymbol } from '@/components/IconSymbol';
import * as Haptics from 'expo-haptics';

export default function HomeScreen() {
  const { hunter, loading, awaken, resetHunter } = useHunter();
  const [showAwakening, setShowAwakening] = useState(false);

  useEffect(() => {
    if (!loading && !hunter) {
      setShowAwakening(true);
    }
  }, [loading, hunter]);

  const handleAwaken = async (name: string) => {
    await awaken(name);
    setShowAwakening(false);
  };

  const handleReset = () => {
    Alert.alert(
      'Reset Hunter',
      'Are you sure you want to reset your hunter? This will delete all progress.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Reset',
          style: 'destructive',
          onPress: async () => {
            await resetHunter();
            setShowAwakening(true);
          },
        },
      ]
    );
  };

  const renderHeaderRight = () => (
    <Pressable onPress={handleReset} style={styles.headerButton}>
      <IconSymbol name="arrow.clockwise" color={colors.neonBlue} size={20} />
    </Pressable>
  );

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <BlackOrb size={150} animated={true} />
        <Text style={styles.loadingText}>Initializing System...</Text>
      </View>
    );
  }

  if (!hunter) {
    return (
      <>
        <AwakeningModal visible={showAwakening} onAwaken={handleAwaken} />
        <View style={styles.loadingContainer}>
          <BlackOrb size={150} animated={true} />
          <Text style={styles.loadingText}>Preparing awakening...</Text>
        </View>
      </>
    );
  }

  const xpPercentage = (hunter.xp / hunter.xpToNext) * 100;

  return (
    <>
      {Platform.OS === 'ios' && (
        <Stack.Screen
          options={{
            title: 'Hunter Status',
            headerRight: renderHeaderRight,
            headerStyle: {
              backgroundColor: colors.background,
            },
            headerTintColor: colors.text,
          }}
        />
      )}
      <ScrollView
        style={styles.container}
        contentContainerStyle={[
          styles.contentContainer,
          Platform.OS !== 'ios' && styles.contentContainerWithTabBar,
        ]}
      >
        {/* Orb Display */}
        <View style={styles.orbSection}>
          <BlackOrb size={180} animated={true} />
          <View style={styles.orbInfo}>
            <Text style={styles.orbLabel}>System Status</Text>
            <Text style={styles.orbStatus}>ACTIVE</Text>
          </View>
        </View>

        {/* Hunter Profile Card */}
        <View style={styles.glassCard}>
          <BlurView intensity={20} tint="dark" style={styles.blurContainer}>
            <LinearGradient
              colors={['rgba(30, 41, 59, 0.8)', 'rgba(30, 41, 59, 0.4)']}
              style={styles.gradientOverlay}
            >
              <View style={styles.profileHeader}>
                <View style={styles.profileInfo}>
                  <Text style={styles.hunterName}>{hunter.name}</Text>
                  <Text style={styles.hunterTitle}>HUNTER</Text>
                </View>
                <RankBadge rank={hunter.rank} size="large" />
              </View>

              <View style={styles.levelContainer}>
                <View style={styles.levelInfo}>
                  <Text style={styles.levelLabel}>LEVEL</Text>
                  <Text style={styles.levelValue}>{hunter.level}</Text>
                  <View style={styles.levelGlow} />
                </View>
                <View style={styles.powerInfo}>
                  <Text style={styles.powerLabel}>POWER</Text>
                  <Text style={styles.powerValue}>{hunter.totalPower.toFixed(1)}</Text>
                  <View style={styles.powerGlow} />
                </View>
              </View>

              {/* XP Progress Bar */}
              <View style={styles.xpContainer}>
                <View style={styles.xpHeader}>
                  <Text style={styles.xpLabel}>EXPERIENCE</Text>
                  <Text style={styles.xpText}>
                    {hunter.xp} / {hunter.xpToNext} XP
                  </Text>
                </View>
                <View style={styles.xpBarBackground}>
                  <LinearGradient
                    colors={[colors.neonCyan, colors.neonBlue]}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 0 }}
                    style={[styles.xpBarFill, { width: `${xpPercentage}%` }]}
                  />
                  <View style={[styles.xpGlow, { width: `${xpPercentage}%` }]} />
                </View>
              </View>
            </LinearGradient>
          </BlurView>
        </View>

        {/* Stats Card */}
        <View style={styles.glassCard}>
          <BlurView intensity={20} tint="dark" style={styles.blurContainer}>
            <LinearGradient
              colors={['rgba(30, 41, 59, 0.8)', 'rgba(30, 41, 59, 0.4)']}
              style={styles.gradientOverlay}
            >
              <View style={styles.sectionHeader}>
                <Text style={styles.sectionTitle}>STATS WINDOW</Text>
                <View style={styles.sectionLine} />
              </View>
              <StatBar statName="STR" value={hunter.stats.STR} />
              <StatBar statName="AGI" value={hunter.stats.AGI} />
              <StatBar statName="INT" value={hunter.stats.INT} />
              <StatBar statName="STA" value={hunter.stats.STA} />
              <StatBar statName="PER" value={hunter.stats.PER} />
              <StatBar statName="MAG" value={hunter.stats.MAG} />
            </LinearGradient>
          </BlurView>
        </View>

        {/* Info Card */}
        <View style={styles.glassCard}>
          <BlurView intensity={20} tint="dark" style={styles.blurContainer}>
            <LinearGradient
              colors={['rgba(30, 41, 59, 0.8)', 'rgba(30, 41, 59, 0.4)']}
              style={[styles.gradientOverlay, styles.infoCardContent]}
            >
              <IconSymbol name="info.circle.fill" size={24} color={colors.neonBlue} />
              <Text style={styles.infoText}>
                Complete daily quests to gain XP and improve your stats. Level up to increase your rank and become a stronger hunter!
              </Text>
            </LinearGradient>
          </BlurView>
        </View>
      </ScrollView>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  contentContainer: {
    padding: 16,
  },
  contentContainerWithTabBar: {
    paddingBottom: 100,
  },
  loadingContainer: {
    flex: 1,
    backgroundColor: colors.background,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 24,
  },
  loadingText: {
    fontSize: 16,
    color: colors.neonBlue,
    fontWeight: '600',
    letterSpacing: 2,
  },
  headerButton: {
    padding: 8,
  },
  orbSection: {
    alignItems: 'center',
    marginVertical: 20,
    gap: 16,
  },
  orbInfo: {
    alignItems: 'center',
    gap: 4,
  },
  orbLabel: {
    fontSize: 12,
    color: colors.textSecondary,
    fontWeight: '600',
    letterSpacing: 2,
  },
  orbStatus: {
    fontSize: 18,
    color: colors.neonBlue,
    fontWeight: '900',
    letterSpacing: 3,
  },
  glassCard: {
    borderRadius: 16,
    marginBottom: 16,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(59, 130, 246, 0.2)',
  },
  blurContainer: {
    overflow: 'hidden',
  },
  gradientOverlay: {
    padding: 20,
  },
  profileHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
  },
  profileInfo: {
    flex: 1,
  },
  hunterName: {
    fontSize: 32,
    fontWeight: '900',
    color: colors.text,
    marginBottom: 4,
    letterSpacing: 1,
  },
  hunterTitle: {
    fontSize: 14,
    color: colors.neonBlue,
    fontWeight: '700',
    letterSpacing: 3,
  },
  levelContainer: {
    flexDirection: 'row',
    gap: 16,
    marginBottom: 24,
  },
  levelInfo: {
    flex: 1,
    backgroundColor: colors.backgroundSecondary,
    borderRadius: 12,
    padding: 20,
    alignItems: 'center',
    position: 'relative',
    borderWidth: 1,
    borderColor: 'rgba(59, 130, 246, 0.3)',
  },
  levelLabel: {
    fontSize: 11,
    color: colors.textSecondary,
    marginBottom: 8,
    fontWeight: '700',
    letterSpacing: 2,
  },
  levelValue: {
    fontSize: 36,
    fontWeight: '900',
    color: colors.neonBlue,
    textShadowColor: colors.neonBlue,
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 10,
  },
  levelGlow: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 4,
    backgroundColor: colors.neonBlue,
    boxShadow: `0 0 20px ${colors.neonBlue}`,
  },
  powerInfo: {
    flex: 1,
    backgroundColor: colors.backgroundSecondary,
    borderRadius: 12,
    padding: 20,
    alignItems: 'center',
    position: 'relative',
    borderWidth: 1,
    borderColor: 'rgba(139, 92, 246, 0.3)',
  },
  powerLabel: {
    fontSize: 11,
    color: colors.textSecondary,
    marginBottom: 8,
    fontWeight: '700',
    letterSpacing: 2,
  },
  powerValue: {
    fontSize: 36,
    fontWeight: '900',
    color: colors.neonPurple,
    textShadowColor: colors.neonPurple,
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 10,
  },
  powerGlow: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 4,
    backgroundColor: colors.neonPurple,
    boxShadow: `0 0 20px ${colors.neonPurple}`,
  },
  xpContainer: {
    marginTop: 4,
  },
  xpHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  xpLabel: {
    fontSize: 12,
    fontWeight: '700',
    color: colors.text,
    letterSpacing: 2,
  },
  xpText: {
    fontSize: 12,
    fontWeight: '700',
    color: colors.neonCyan,
    letterSpacing: 1,
  },
  xpBarBackground: {
    height: 14,
    backgroundColor: colors.backgroundSecondary,
    borderRadius: 7,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(6, 182, 212, 0.3)',
    position: 'relative',
  },
  xpBarFill: {
    height: '100%',
    borderRadius: 7,
  },
  xpGlow: {
    position: 'absolute',
    top: 0,
    left: 0,
    height: '100%',
    boxShadow: `0 0 15px ${colors.neonCyan}`,
  },
  sectionHeader: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '900',
    color: colors.text,
    marginBottom: 8,
    letterSpacing: 2,
  },
  sectionLine: {
    height: 2,
    backgroundColor: colors.neonBlue,
    width: 60,
    boxShadow: `0 0 10px ${colors.neonBlue}`,
  },
  infoCardContent: {
    flexDirection: 'row',
    gap: 12,
    alignItems: 'flex-start',
  },
  infoText: {
    flex: 1,
    fontSize: 14,
    color: colors.textSecondary,
    lineHeight: 20,
  },
});
