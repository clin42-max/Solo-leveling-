
import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Platform, Pressable, Alert } from 'react-native';
import { Stack } from 'expo-router';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { colors } from '@/styles/commonStyles';
import { IconSymbol } from '@/components/IconSymbol';
import { useHunter } from '@/hooks/useHunter';
import QuestCard from '@/components/QuestCard';
import LevelUpModal from '@/components/LevelUpModal';
import * as Haptics from 'expo-haptics';

export default function QuestsScreen() {
  const { hunter, completeQuest, resetQuests } = useHunter();
  const [levelUpData, setLevelUpData] = useState<any>(null);

  const handleCompleteQuest = async (questId: string) => {
    const result = await completeQuest(questId);
    if (result?.leveledUp) {
      setLevelUpData(result);
    }
  };

  const handleResetQuests = () => {
    Alert.alert(
      'Reset Quests',
      'Are you sure you want to reset all quests? This will generate new daily quests.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Reset',
          style: 'destructive',
          onPress: async () => {
            await resetQuests();
          },
        },
      ]
    );
  };

  const renderHeaderRight = () => (
    <Pressable onPress={handleResetQuests} style={styles.headerButton}>
      <IconSymbol name="arrow.clockwise" color={colors.neonBlue} size={20} />
    </Pressable>
  );

  if (!hunter) {
    return (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyText}>No hunter data available</Text>
      </View>
    );
  }

  const completedQuests = hunter.quests.filter(q => q.completed).length;
  const totalQuests = hunter.quests.length;

  return (
    <>
      {Platform.OS === 'ios' && (
        <Stack.Screen
          options={{
            title: 'Daily Quests',
            headerRight: renderHeaderRight,
            headerStyle: {
              backgroundColor: colors.background,
            },
            headerTintColor: colors.text,
          }}
        />
      )}
      <ScrollView
        style={styles.container}
        contentContainerStyle={[
          styles.contentContainer,
          Platform.OS !== 'ios' && styles.contentContainerWithTabBar,
        ]}
      >
        {/* Quest Progress Card */}
        <View style={styles.glassCard}>
          <BlurView intensity={20} tint="dark" style={styles.blurContainer}>
            <LinearGradient
              colors={['rgba(30, 41, 59, 0.8)', 'rgba(30, 41, 59, 0.4)']}
              style={styles.gradientOverlay}
            >
              <View style={styles.progressHeader}>
                <View>
                  <Text style={styles.progressTitle}>QUEST PROGRESS</Text>
                  <Text style={styles.progressSubtitle}>Daily Missions</Text>
                </View>
                <View style={styles.progressCircle}>
                  <Text style={styles.progressText}>
                    {completedQuests}/{totalQuests}
                  </Text>
                </View>
              </View>
              
              <View style={styles.progressBarContainer}>
                <View style={styles.progressBarBackground}>
                  <LinearGradient
                    colors={[colors.neonCyan, colors.neonBlue]}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 0 }}
                    style={[
                      styles.progressBarFill,
                      { width: `${(completedQuests / totalQuests) * 100}%` },
                    ]}
                  />
                </View>
              </View>
            </LinearGradient>
          </BlurView>
        </View>

        {/* Quest List */}
        <View style={styles.questList}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>AVAILABLE QUESTS</Text>
            <View style={styles.sectionLine} />
          </View>
          
          {hunter.quests.map((quest) => (
            <QuestCard
              key={quest.id}
              quest={quest}
              onComplete={handleCompleteQuest}
            />
          ))}
        </View>

        {/* Info Card */}
        <View style={styles.glassCard}>
          <BlurView intensity={20} tint="dark" style={styles.blurContainer}>
            <LinearGradient
              colors={['rgba(30, 41, 59, 0.8)', 'rgba(30, 41, 59, 0.4)']}
              style={[styles.gradientOverlay, styles.infoCardContent]}
            >
              <IconSymbol name="info.circle.fill" size={24} color={colors.neonBlue} />
              <Text style={styles.infoText}>
                Complete quests to earn XP and stat bonuses. New quests are generated daily!
              </Text>
            </LinearGradient>
          </BlurView>
        </View>
      </ScrollView>

      {levelUpData && (
        <LevelUpModal
          visible={!!levelUpData}
          newLevel={levelUpData.newLevel}
          newRank={levelUpData.newRank}
          statGains={levelUpData.statGains}
          onClose={() => setLevelUpData(null)}
        />
      )}
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  contentContainer: {
    padding: 16,
  },
  contentContainerWithTabBar: {
    paddingBottom: 100,
  },
  emptyContainer: {
    flex: 1,
    backgroundColor: colors.background,
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: colors.textSecondary,
  },
  headerButton: {
    padding: 8,
  },
  glassCard: {
    borderRadius: 16,
    marginBottom: 16,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(59, 130, 246, 0.2)',
  },
  blurContainer: {
    overflow: 'hidden',
  },
  gradientOverlay: {
    padding: 20,
  },
  progressHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  progressTitle: {
    fontSize: 18,
    fontWeight: '900',
    color: colors.text,
    letterSpacing: 2,
  },
  progressSubtitle: {
    fontSize: 12,
    color: colors.textSecondary,
    marginTop: 4,
    letterSpacing: 1,
  },
  progressCircle: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: colors.backgroundSecondary,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: colors.neonBlue,
    boxShadow: `0 0 20px ${colors.neonBlue}`,
  },
  progressText: {
    fontSize: 16,
    fontWeight: '900',
    color: colors.neonBlue,
  },
  progressBarContainer: {
    marginTop: 8,
  },
  progressBarBackground: {
    height: 12,
    backgroundColor: colors.backgroundSecondary,
    borderRadius: 6,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(6, 182, 212, 0.3)',
  },
  progressBarFill: {
    height: '100%',
    borderRadius: 6,
  },
  questList: {
    marginBottom: 16,
  },
  sectionHeader: {
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '900',
    color: colors.text,
    marginBottom: 8,
    letterSpacing: 2,
  },
  sectionLine: {
    height: 2,
    backgroundColor: colors.neonBlue,
    width: 60,
    boxShadow: `0 0 10px ${colors.neonBlue}`,
  },
  infoCardContent: {
    flexDirection: 'row',
    gap: 12,
    alignItems: 'flex-start',
  },
  infoText: {
    flex: 1,
    fontSize: 14,
    color: colors.textSecondary,
    lineHeight: 20,
  },
});
