
import React, { useEffect } from 'react';
import { View, StyleSheet, Dimensions } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withTiming,
  withSequence,
  Easing,
  interpolate,
} from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { colors } from '@/styles/commonStyles';

interface BlackOrbProps {
  size?: number;
  animated?: boolean;
}

const { width } = Dimensions.get('window');

export default function BlackOrb({ size = 200, animated = true }: BlackOrbProps) {
  const rotation = useSharedValue(0);
  const pulse = useSharedValue(1);
  const glow = useSharedValue(0);

  useEffect(() => {
    if (animated) {
      // Continuous rotation
      rotation.value = withRepeat(
        withTiming(360, {
          duration: 20000,
          easing: Easing.linear,
        }),
        -1,
        false
      );

      // Pulsing effect
      pulse.value = withRepeat(
        withSequence(
          withTiming(1.1, { duration: 2000, easing: Easing.inOut(Easing.ease) }),
          withTiming(1, { duration: 2000, easing: Easing.inOut(Easing.ease) })
        ),
        -1,
        false
      );

      // Glow effect
      glow.value = withRepeat(
        withSequence(
          withTiming(1, { duration: 1500, easing: Easing.inOut(Easing.ease) }),
          withTiming(0, { duration: 1500, easing: Easing.inOut(Easing.ease) })
        ),
        -1,
        false
      );
    }
  }, [animated]);

  const orbAnimatedStyle = useAnimatedStyle(() => {
    return {
      transform: [
        { scale: pulse.value },
        { rotate: `${rotation.value}deg` },
      ],
    };
  });

  const glowAnimatedStyle = useAnimatedStyle(() => {
    const opacity = interpolate(glow.value, [0, 1], [0.3, 0.8]);
    const scale = interpolate(glow.value, [0, 1], [1, 1.2]);
    
    return {
      opacity,
      transform: [{ scale }],
    };
  });

  const particleAnimatedStyle = (delay: number) => useAnimatedStyle(() => {
    const particleRotation = rotation.value + delay;
    return {
      transform: [{ rotate: `${particleRotation}deg` }],
    };
  });

  return (
    <View style={[styles.container, { width: size, height: size }]}>
      {/* Outer glow layers */}
      <Animated.View style={[styles.glowOuter, glowAnimatedStyle]}>
        <View style={[styles.glowCircle, { width: size * 1.5, height: size * 1.5 }]} />
      </Animated.View>

      {/* Particle rings */}
      {[0, 120, 240].map((delay, index) => (
        <Animated.View
          key={index}
          style={[
            styles.particleRing,
            { width: size * 1.3, height: size * 1.3 },
            particleAnimatedStyle(delay),
          ]}
        >
          <View style={styles.particle} />
        </Animated.View>
      ))}

      {/* Main orb with animation */}
      <Animated.View style={[styles.orbContainer, orbAnimatedStyle]}>
        {/* Inner glow */}
        <View style={[styles.innerGlow, { width: size, height: size }]}>
          <LinearGradient
            colors={[colors.orbGlow, 'transparent']}
            style={styles.gradientGlow}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
          />
        </View>

        {/* Core black orb */}
        <View style={[styles.orbCore, { width: size * 0.85, height: size * 0.85 }]}>
          <LinearGradient
            colors={['#1a1a2e', '#000000', '#000000']}
            style={styles.coreGradient}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
          />
          
          {/* Highlight reflection */}
          <View style={styles.highlight} />
        </View>
      </Animated.View>

      {/* Energy rings */}
      <Animated.View style={[styles.energyRing, orbAnimatedStyle]}>
        <View style={[styles.ring, { width: size * 1.1, height: size * 1.1 }]} />
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  glowOuter: {
    position: 'absolute',
    justifyContent: 'center',
    alignItems: 'center',
  },
  glowCircle: {
    borderRadius: 9999,
    backgroundColor: colors.orbGlow,
    opacity: 0.2,
    boxShadow: `0 0 60px ${colors.orbGlow}`,
  },
  particleRing: {
    position: 'absolute',
    justifyContent: 'flex-start',
    alignItems: 'center',
  },
  particle: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: colors.orbParticle,
    boxShadow: `0 0 10px ${colors.orbParticle}`,
  },
  orbContainer: {
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 10,
  },
  innerGlow: {
    position: 'absolute',
    borderRadius: 9999,
    overflow: 'hidden',
  },
  gradientGlow: {
    width: '100%',
    height: '100%',
    borderRadius: 9999,
  },
  orbCore: {
    borderRadius: 9999,
    overflow: 'hidden',
    boxShadow: '0 0 40px rgba(59, 130, 246, 0.5)',
    borderWidth: 2,
    borderColor: colors.orbGlow,
  },
  coreGradient: {
    width: '100%',
    height: '100%',
    borderRadius: 9999,
  },
  highlight: {
    position: 'absolute',
    top: '15%',
    left: '20%',
    width: '30%',
    height: '30%',
    borderRadius: 9999,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    boxShadow: '0 0 20px rgba(255, 255, 255, 0.3)',
  },
  energyRing: {
    position: 'absolute',
  },
  ring: {
    borderRadius: 9999,
    borderWidth: 2,
    borderColor: colors.neonBlue,
    opacity: 0.3,
  },
});
