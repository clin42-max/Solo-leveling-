
import React, { useEffect } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withSequence,
  withTiming,
  Easing,
} from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { HunterRank } from '@/types/hunter';
import { getRankColor } from '@/utils/hunterCalculations';

interface RankBadgeProps {
  rank: HunterRank;
  size?: 'small' | 'medium' | 'large';
}

export default function RankBadge({ rank, size = 'medium' }: RankBadgeProps) {
  const rankColor = getRankColor(rank);
  const sizeStyles = getSizeStyles(size);
  const glow = useSharedValue(0);

  useEffect(() => {
    glow.value = withRepeat(
      withSequence(
        withTiming(1, { duration: 1500, easing: Easing.inOut(Easing.ease) }),
        withTiming(0, { duration: 1500, easing: Easing.inOut(Easing.ease) })
      ),
      -1,
      false
    );
  }, []);

  const glowStyle = useAnimatedStyle(() => {
    return {
      opacity: glow.value * 0.6,
    };
  });

  return (
    <View style={[styles.container, sizeStyles.container]}>
      <Animated.View style={[styles.glowContainer, glowStyle]}>
        <View style={[styles.glow, sizeStyles.container, { backgroundColor: rankColor }]} />
      </Animated.View>
      <LinearGradient
        colors={[rankColor, `${rankColor}cc`]}
        style={[styles.badge, sizeStyles.container]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
      >
        <Text style={[styles.rankText, sizeStyles.text]}>{rank}</Text>
      </LinearGradient>
    </View>
  );
}

function getSizeStyles(size: 'small' | 'medium' | 'large') {
  switch (size) {
    case 'small':
      return {
        container: { width: 40, height: 40, borderRadius: 20 },
        text: { fontSize: 14 },
      };
    case 'large':
      return {
        container: { width: 80, height: 80, borderRadius: 40 },
        text: { fontSize: 32 },
      };
    default:
      return {
        container: { width: 60, height: 60, borderRadius: 30 },
        text: { fontSize: 24 },
      };
  }
}

const styles = StyleSheet.create({
  container: {
    position: 'relative',
    justifyContent: 'center',
    alignItems: 'center',
  },
  glowContainer: {
    position: 'absolute',
  },
  glow: {
    boxShadow: '0 0 30px currentColor',
  },
  badge: {
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.3)',
  },
  rankText: {
    fontWeight: '900',
    color: '#ffffff',
    textShadowColor: 'rgba(0, 0, 0, 0.5)',
    textShadowOffset: { width: 0, height: 2 },
    textShadowRadius: 4,
  },
});
