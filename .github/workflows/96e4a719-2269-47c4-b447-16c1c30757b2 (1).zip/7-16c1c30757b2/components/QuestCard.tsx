
import React from 'react';
import { View, Text, StyleSheet, Pressable } from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Quest } from '@/types/hunter';
import { IconSymbol } from './IconSymbol';
import { colors } from '@/styles/commonStyles';
import { getQuestTypeColor, getDifficultyStars } from '@/data/questGenerator';
import * as Haptics from 'expo-haptics';

interface QuestCardProps {
  quest: Quest;
  onComplete: (questId: string) => void;
}

export default function QuestCard({ quest, onComplete }: QuestCardProps) {
  const typeColor = getQuestTypeColor(quest.type);
  const stars = getDifficultyStars(quest.difficulty);

  const handlePress = () => {
    if (!quest.completed) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      onComplete(quest.id);
    }
  };

  return (
    <Pressable
      style={({ pressed }) => [
        styles.container,
        quest.completed && styles.completedContainer,
        pressed && styles.pressedContainer,
      ]}
      onPress={handlePress}
      disabled={quest.completed}
    >
      <BlurView intensity={20} tint="dark" style={styles.blurContainer}>
        <LinearGradient
          colors={
            quest.completed
              ? ['rgba(30, 41, 59, 0.5)', 'rgba(30, 41, 59, 0.3)']
              : ['rgba(30, 41, 59, 0.8)', 'rgba(30, 41, 59, 0.4)']
          }
          style={styles.gradientOverlay}
        >
          <View style={styles.header}>
            <View style={[styles.typeIndicator, { backgroundColor: typeColor }]}>
              <Text style={styles.typeText}>{quest.type}</Text>
            </View>
            <View style={styles.difficultyContainer}>
              {stars.map((filled, index) => (
                <IconSymbol
                  key={index}
                  name={filled ? 'star.fill' : 'star'}
                  size={14}
                  color={filled ? colors.neonCyan : colors.textSecondary}
                />
              ))}
            </View>
          </View>

          <Text style={[styles.title, quest.completed && styles.completedText]}>
            {quest.title}
          </Text>

          <View style={styles.footer}>
            <View style={styles.rewardContainer}>
              <IconSymbol name="bolt.fill" size={16} color={colors.neonCyan} />
              <Text style={styles.rewardText}>{quest.xp_reward} XP</Text>
            </View>

            {quest.completed ? (
              <View style={styles.completedBadge}>
                <IconSymbol name="checkmark.circle.fill" size={20} color={colors.neonGreen} />
                <Text style={styles.completedBadgeText}>COMPLETE</Text>
              </View>
            ) : (
              <View style={styles.actionButton}>
                <Text style={styles.actionButtonText}>TAP TO COMPLETE</Text>
              </View>
            )}
          </View>
        </LinearGradient>
      </BlurView>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: {
    borderRadius: 12,
    marginBottom: 12,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(59, 130, 246, 0.3)',
  },
  completedContainer: {
    opacity: 0.6,
    borderColor: 'rgba(16, 185, 129, 0.3)',
  },
  pressedContainer: {
    opacity: 0.8,
  },
  blurContainer: {
    overflow: 'hidden',
  },
  gradientOverlay: {
    padding: 16,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  typeIndicator: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
    boxShadow: '0 0 10px currentColor',
  },
  typeText: {
    fontSize: 10,
    fontWeight: '700',
    color: '#ffffff',
    letterSpacing: 1,
  },
  difficultyContainer: {
    flexDirection: 'row',
    gap: 4,
  },
  title: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.text,
    marginBottom: 12,
    lineHeight: 22,
  },
  completedText: {
    textDecorationLine: 'line-through',
    color: colors.textSecondary,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  rewardContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  rewardText: {
    fontSize: 14,
    fontWeight: '700',
    color: colors.neonCyan,
    letterSpacing: 1,
  },
  completedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  completedBadgeText: {
    fontSize: 12,
    fontWeight: '700',
    color: colors.neonGreen,
    letterSpacing: 1,
  },
  actionButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: colors.neonBlue,
  },
  actionButtonText: {
    fontSize: 10,
    fontWeight: '700',
    color: colors.neonBlue,
    letterSpacing: 1,
  },
});
