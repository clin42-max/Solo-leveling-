
import React, { useEffect } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
  withTiming,
  Easing,
} from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { colors } from '@/styles/commonStyles';
import { getStatColor } from '@/utils/hunterCalculations';
import { Stats } from '@/types/hunter';

interface StatBarProps {
  statName: keyof Stats;
  value: number;
  maxValue?: number;
}

export default function StatBar({ statName, value, maxValue = 100 }: StatBarProps) {
  const percentage = (value / maxValue) * 100;
  const statColor = getStatColor(statName);
  const animatedWidth = useSharedValue(0);
  const glowOpacity = useSharedValue(0);

  useEffect(() => {
    animatedWidth.value = withSpring(percentage, {
      damping: 15,
      stiffness: 100,
    });

    glowOpacity.value = withTiming(1, {
      duration: 1000,
      easing: Easing.inOut(Easing.ease),
    });
  }, [percentage]);

  const animatedStyle = useAnimatedStyle(() => {
    return {
      width: `${animatedWidth.value}%`,
    };
  });

  const glowStyle = useAnimatedStyle(() => {
    return {
      opacity: glowOpacity.value,
    };
  });

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.statName}>{statName}</Text>
        <Text style={[styles.statValue, { color: statColor }]}>{value}</Text>
      </View>
      <View style={styles.barContainer}>
        <View style={styles.barBackground}>
          <Animated.View style={[styles.barFill, animatedStyle]}>
            <LinearGradient
              colors={[statColor, `${statColor}99`]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={styles.gradient}
            />
            <Animated.View style={[styles.barGlow, glowStyle, { backgroundColor: statColor }]} />
          </Animated.View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginVertical: 8,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 6,
  },
  statName: {
    fontSize: 14,
    fontWeight: '700',
    color: colors.text,
    letterSpacing: 1,
  },
  statValue: {
    fontSize: 16,
    fontWeight: '900',
    letterSpacing: 0.5,
  },
  barContainer: {
    width: '100%',
  },
  barBackground: {
    height: 10,
    backgroundColor: colors.backgroundSecondary,
    borderRadius: 5,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(59, 130, 246, 0.2)',
  },
  barFill: {
    height: '100%',
    borderRadius: 5,
    position: 'relative',
    overflow: 'hidden',
  },
  gradient: {
    width: '100%',
    height: '100%',
  },
  barGlow: {
    position: 'absolute',
    right: 0,
    top: 0,
    bottom: 0,
    width: 4,
    boxShadow: '0 0 10px currentColor',
  },
});
