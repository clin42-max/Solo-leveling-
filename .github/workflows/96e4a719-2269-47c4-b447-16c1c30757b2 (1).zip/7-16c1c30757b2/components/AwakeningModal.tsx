
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  TextInput,
  Pressable,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withSequence,
  withTiming,
  Easing,
} from 'react-native-reanimated';
import { IconSymbol } from './IconSymbol';
import BlackOrb from './BlackOrb';
import { colors } from '@/styles/commonStyles';
import * as Haptics from 'expo-haptics';

interface AwakeningModalProps {
  visible: boolean;
  onAwaken: (name: string) => void;
}

export default function AwakeningModal({ visible, onAwaken }: AwakeningModalProps) {
  const [name, setName] = useState('');
  const pulse = useSharedValue(1);

  useEffect(() => {
    if (visible) {
      pulse.value = withRepeat(
        withSequence(
          withTiming(1.05, { duration: 1000, easing: Easing.inOut(Easing.ease) }),
          withTiming(1, { duration: 1000, easing: Easing.inOut(Easing.ease) })
        ),
        -1,
        false
      );
    }
  }, [visible]);

  const animatedStyle = useAnimatedStyle(() => {
    return {
      transform: [{ scale: pulse.value }],
    };
  });

  const handleAwaken = () => {
    if (name.trim()) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
      onAwaken(name.trim());
      setName('');
    }
  };

  return (
    <Modal visible={visible} transparent animationType="fade">
      <BlurView intensity={80} tint="dark" style={styles.modalContainer}>
        <KeyboardAvoidingView
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          style={styles.keyboardView}
        >
          <View style={styles.modalContent}>
            {/* Animated Orb */}
            <Animated.View style={[styles.orbContainer, animatedStyle]}>
              <BlackOrb size={200} animated={true} />
            </Animated.View>

            {/* Title */}
            <Text style={styles.title}>AWAKENING SYSTEM</Text>
            <Text style={styles.subtitle}>Initialize Hunter Profile</Text>

            {/* Input Card */}
            <View style={styles.inputCard}>
              <BlurView intensity={20} tint="dark" style={styles.inputBlur}>
                <LinearGradient
                  colors={['rgba(30, 41, 59, 0.9)', 'rgba(30, 41, 59, 0.6)']}
                  style={styles.inputGradient}
                >
                  <Text style={styles.inputLabel}>HUNTER NAME</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="Enter your name..."
                    placeholderTextColor={colors.textSecondary}
                    value={name}
                    onChangeText={setName}
                    autoFocus
                    maxLength={20}
                  />
                </LinearGradient>
              </BlurView>
            </View>

            {/* Awaken Button */}
            <Pressable
              style={({ pressed }) => [
                styles.awakenButton,
                pressed && styles.awakenButtonPressed,
              ]}
              onPress={handleAwaken}
              disabled={!name.trim()}
            >
              <LinearGradient
                colors={name.trim() ? [colors.neonBlue, colors.neonPurple] : ['#374151', '#1f2937']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={styles.buttonGradient}
              >
                <IconSymbol name="bolt.fill" size={24} color="#ffffff" />
                <Text style={styles.awakenButtonText}>AWAKEN</Text>
              </LinearGradient>
            </Pressable>

            {/* Info Text */}
            <Text style={styles.infoText}>
              The system will evaluate your abilities and assign your initial stats
            </Text>
          </View>
        </KeyboardAvoidingView>
      </BlurView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  keyboardView: {
    width: '100%',
    alignItems: 'center',
    padding: 20,
  },
  modalContent: {
    width: '100%',
    maxWidth: 400,
    alignItems: 'center',
    gap: 20,
  },
  orbContainer: {
    marginBottom: 20,
  },
  title: {
    fontSize: 32,
    fontWeight: '900',
    color: colors.text,
    letterSpacing: 3,
    textAlign: 'center',
    textShadowColor: colors.neonBlue,
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 20,
  },
  subtitle: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.neonBlue,
    letterSpacing: 2,
    textAlign: 'center',
  },
  inputCard: {
    width: '100%',
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(59, 130, 246, 0.3)',
  },
  inputBlur: {
    overflow: 'hidden',
  },
  inputGradient: {
    padding: 20,
  },
  inputLabel: {
    fontSize: 12,
    fontWeight: '700',
    color: colors.textSecondary,
    marginBottom: 10,
    letterSpacing: 2,
  },
  input: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    padding: 12,
    backgroundColor: colors.backgroundSecondary,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: 'rgba(59, 130, 246, 0.3)',
  },
  awakenButton: {
    width: '100%',
    borderRadius: 12,
    overflow: 'hidden',
    boxShadow: '0 0 30px rgba(59, 130, 246, 0.5)',
  },
  awakenButtonPressed: {
    opacity: 0.8,
  },
  buttonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
    padding: 18,
  },
  awakenButtonText: {
    fontSize: 18,
    fontWeight: '900',
    color: '#ffffff',
    letterSpacing: 2,
  },
  infoText: {
    fontSize: 12,
    color: colors.textSecondary,
    textAlign: 'center',
    lineHeight: 18,
    paddingHorizontal: 20,
  },
});
