
import { Stats, HunterRank } from '@/types/hunter';

// Calculate total power based on weighted stats
export function calculateTotalPower(stats: Stats): number {
  const power = 
    stats.STR * 0.24 +
    stats.AGI * 0.18 +
    stats.INT * 0.22 +
    stats.STA * 0.16 +
    stats.PER * 0.10 +
    stats.MAG * 0.10;
  
  return Math.round(power * 100) / 100;
}

// Determine rank based on total power
export function calculateRank(totalPower: number): HunterRank {
  if (totalPower >= 98) return 'S+';
  if (totalPower >= 91) return 'S';
  if (totalPower >= 80) return 'A';
  if (totalPower >= 65) return 'B';
  if (totalPower >= 45) return 'C';
  if (totalPower >= 25) return 'D';
  return 'E';
}

// Calculate XP required for next level
export function calculateXPToNext(level: number): number {
  return Math.floor(100 * Math.pow(level, 1.4));
}

// Generate base stats for awakening (with some randomness)
export function generateBaseStats(): Stats {
  const randomStat = (min: number, max: number) => 
    Math.floor(Math.random() * (max - min + 1)) + min;
  
  return {
    STR: randomStat(20, 50),
    AGI: randomStat(20, 50),
    INT: randomStat(20, 50),
    STA: randomStat(20, 50),
    PER: randomStat(15, 45),
    MAG: randomStat(15, 45),
  };
}

// Apply stat growth on level up
export function applyStatGrowth(stats: Stats): Stats {
  const growth = (base: number) => {
    const variance = Math.random() * 0.4 - 0.2; // -0.2 to +0.2
    return Math.min(100, Math.round(base + 1 + variance));
  };
  
  return {
    STR: growth(stats.STR),
    AGI: growth(stats.AGI),
    INT: growth(stats.INT),
    STA: growth(stats.STA),
    PER: growth(stats.PER),
    MAG: growth(stats.MAG),
  };
}

// Get rank color
export function getRankColor(rank: HunterRank): string {
  const colors = {
    'E': '#8d6e63',
    'D': '#78909c',
    'C': '#66bb6a',
    'B': '#42a5f5',
    'A': '#ab47bc',
    'S': '#ffa726',
    'S+': '#ef5350',
  };
  return colors[rank];
}

// Get stat color
export function getStatColor(statName: keyof Stats): string {
  const colors = {
    STR: '#e57373',
    AGI: '#81c784',
    INT: '#64b5f6',
    STA: '#ffb74d',
    PER: '#ba68c8',
    MAG: '#9575cd',
  };
  return colors[statName];
}
