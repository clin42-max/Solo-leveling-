
import { Quest, QuestType, QuestDifficulty, Stats } from '@/types/hunter';

// Generate daily quests based on user stats
export function generateDailyQuests(userStats: Stats): Quest[] {
  const quests: Quest[] = [
    // Physical Quests
    {
      id: 'q1',
      title: 'Push Your Limits',
      description: 'Complete 30 push-ups',
      type: 'Physical',
      difficulty: 2,
      xpReward: 50,
      statRewards: { STR: 1 },
      completed: false,
      dailyReset: true,
    },
    {
      id: 'q2',
      title: 'Daily Steps Challenge',
      description: 'Walk 10,000 steps',
      type: 'Physical',
      difficulty: 3,
      xpReward: 75,
      statRewards: { STA: 1, AGI: 1 },
      completed: false,
      dailyReset: true,
    },
    {
      id: 'q3',
      title: 'Sprint Training',
      description: 'Run for 20 minutes',
      type: 'Physical',
      difficulty: 3,
      xpReward: 80,
      statRewards: { AGI: 2, STA: 1 },
      completed: false,
      dailyReset: true,
    },
    // Cognitive Quests
    {
      id: 'q4',
      title: 'Knowledge Seeker',
      description: 'Read for 30 minutes',
      type: 'Cognitive',
      difficulty: 2,
      xpReward: 60,
      statRewards: { INT: 2 },
      completed: false,
      dailyReset: true,
    },
    {
      id: 'q5',
      title: 'Problem Solver',
      description: 'Complete a puzzle or brain teaser',
      type: 'Cognitive',
      difficulty: 3,
      xpReward: 70,
      statRewards: { INT: 1, PER: 1 },
      completed: false,
      dailyReset: true,
    },
    // Recovery Quests
    {
      id: 'q6',
      title: 'Rest and Recover',
      description: 'Get 8 hours of sleep',
      type: 'Recovery',
      difficulty: 2,
      xpReward: 50,
      statRewards: { STA: 1, MAG: 1 },
      completed: false,
      dailyReset: true,
    },
    {
      id: 'q7',
      title: 'Meditation Master',
      description: 'Meditate for 15 minutes',
      type: 'Recovery',
      difficulty: 2,
      xpReward: 55,
      statRewards: { MAG: 2 },
      completed: false,
      dailyReset: true,
    },
    // Social Quests
    {
      id: 'q8',
      title: 'Social Connection',
      description: 'Have a meaningful conversation',
      type: 'Social',
      difficulty: 2,
      xpReward: 45,
      statRewards: { PER: 2 },
      completed: false,
      dailyReset: true,
    },
    // Creative Quests
    {
      id: 'q9',
      title: 'Creative Expression',
      description: 'Create something (art, music, writing)',
      type: 'Creative',
      difficulty: 3,
      xpReward: 65,
      statRewards: { INT: 1, MAG: 1 },
      completed: false,
      dailyReset: true,
    },
  ];

  // Return a random selection of 5 quests
  return shuffleArray(quests).slice(0, 5);
}

function shuffleArray<T>(array: T[]): T[] {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}

export function getQuestTypeColor(type: QuestType): string {
  const colors = {
    Physical: '#e57373',
    Cognitive: '#64b5f6',
    Social: '#ba68c8',
    Creative: '#ffca28',
    Recovery: '#81c784',
  };
  return colors[type];
}

export function getDifficultyStars(difficulty: QuestDifficulty): string {
  return '★'.repeat(difficulty) + '☆'.repeat(5 - difficulty);
}
