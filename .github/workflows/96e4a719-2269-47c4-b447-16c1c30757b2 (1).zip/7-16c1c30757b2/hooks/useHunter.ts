
import { useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Hunter, Quest, QuestHistory, Stats } from '@/types/hunter';
import {
  calculateTotalPower,
  calculateRank,
  calculateXPToNext,
  generateBaseStats,
  applyStatGrowth,
} from '@/utils/hunterCalculations';
import { generateDailyQuests } from '@/data/questGenerator';

const STORAGE_KEY = '@hunter_data';
const QUESTS_KEY = '@hunter_quests';
const HISTORY_KEY = '@hunter_history';

export function useHunter() {
  const [hunter, setHunter] = useState<Hunter | null>(null);
  const [quests, setQuests] = useState<Quest[]>([]);
  const [history, setHistory] = useState<QuestHistory[]>([]);
  const [loading, setLoading] = useState(true);

  // Load hunter data from storage
  useEffect(() => {
    loadHunterData();
  }, []);

  const loadHunterData = async () => {
    try {
      const hunterData = await AsyncStorage.getItem(STORAGE_KEY);
      const questsData = await AsyncStorage.getItem(QUESTS_KEY);
      const historyData = await AsyncStorage.getItem(HISTORY_KEY);

      if (hunterData) {
        setHunter(JSON.parse(hunterData));
      }
      if (questsData) {
        setQuests(JSON.parse(questsData));
      }
      if (historyData) {
        setHistory(JSON.parse(historyData));
      }
    } catch (error) {
      console.error('Error loading hunter data:', error);
    } finally {
      setLoading(false);
    }
  };

  const saveHunterData = async (hunterData: Hunter) => {
    try {
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(hunterData));
      setHunter(hunterData);
    } catch (error) {
      console.error('Error saving hunter data:', error);
    }
  };

  const saveQuests = async (questsData: Quest[]) => {
    try {
      await AsyncStorage.setItem(QUESTS_KEY, JSON.stringify(questsData));
      setQuests(questsData);
    } catch (error) {
      console.error('Error saving quests:', error);
    }
  };

  const saveHistory = async (historyData: QuestHistory[]) => {
    try {
      await AsyncStorage.setItem(HISTORY_KEY, JSON.stringify(historyData));
      setHistory(historyData);
    } catch (error) {
      console.error('Error saving history:', error);
    }
  };

  // Awaken the hunter (initialize stats)
  const awaken = async (name: string) => {
    const baseStats = generateBaseStats();
    const totalPower = calculateTotalPower(baseStats);
    const rank = calculateRank(totalPower);

    const newHunter: Hunter = {
      id: Date.now().toString(),
      name,
      level: 1,
      xp: 0,
      xpToNext: calculateXPToNext(1),
      rank,
      totalPower,
      stats: baseStats,
      awakened: true,
    };

    await saveHunterData(newHunter);

    // Generate initial quests
    const initialQuests = generateDailyQuests(baseStats);
    await saveQuests(initialQuests);

    return newHunter;
  };

  // Complete a quest
  const completeQuest = async (questId: string) => {
    if (!hunter) return;

    const quest = quests.find(q => q.id === questId);
    if (!quest || quest.completed) return;

    // Update quest status
    const updatedQuests = quests.map(q =>
      q.id === questId ? { ...q, completed: true } : q
    );
    await saveQuests(updatedQuests);

    // Add XP and stats
    let newXP = hunter.xp + quest.xpReward;
    let newLevel = hunter.level;
    let newStats = { ...hunter.stats };

    // Apply stat rewards
    Object.entries(quest.statRewards).forEach(([stat, value]) => {
      newStats[stat as keyof Stats] = Math.min(
        100,
        newStats[stat as keyof Stats] + (value || 0)
      );
    });

    // Check for level up
    let xpToNext = hunter.xpToNext;
    while (newXP >= xpToNext) {
      newXP -= xpToNext;
      newLevel += 1;
      newStats = applyStatGrowth(newStats);
      xpToNext = calculateXPToNext(newLevel);
    }

    // Recalculate power and rank
    const totalPower = calculateTotalPower(newStats);
    const rank = calculateRank(totalPower);

    const updatedHunter: Hunter = {
      ...hunter,
      level: newLevel,
      xp: newXP,
      xpToNext,
      rank,
      totalPower,
      stats: newStats,
    };

    await saveHunterData(updatedHunter);

    // Add to history
    const historyEntry: QuestHistory = {
      questId: quest.id,
      questTitle: quest.title,
      completedAt: new Date(),
      xpGained: quest.xpReward,
      statsGained: quest.statRewards,
    };
    await saveHistory([historyEntry, ...history]);

    return { leveledUp: newLevel > hunter.level, newLevel };
  };

  // Reset daily quests
  const resetDailyQuests = async () => {
    if (!hunter) return;

    const newQuests = generateDailyQuests(hunter.stats);
    await saveQuests(newQuests);
  };

  // Reset hunter (for testing)
  const resetHunter = async () => {
    await AsyncStorage.removeItem(STORAGE_KEY);
    await AsyncStorage.removeItem(QUESTS_KEY);
    await AsyncStorage.removeItem(HISTORY_KEY);
    setHunter(null);
    setQuests([]);
    setHistory([]);
  };

  return {
    hunter,
    quests,
    history,
    loading,
    awaken,
    completeQuest,
    resetDailyQuests,
    resetHunter,
  };
}
