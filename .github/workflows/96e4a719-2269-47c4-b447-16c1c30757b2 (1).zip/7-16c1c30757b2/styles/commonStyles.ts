
import { StyleSheet, ViewStyle, TextStyle } from 'react-native';

export const colors = {
  // Futuristic dark theme
  background: '#0a0e1a',
  backgroundSecondary: '#111827',
  text: '#e0e7ff',
  textSecondary: '#94a3b8',
  primary: '#3b82f6',
  secondary: '#8b5cf6',
  accent: '#06b6d4',
  card: '#1e293b',
  cardGlass: 'rgba(30, 41, 59, 0.7)',
  highlight: '#f59e0b',
  
  // Neon colors
  neonBlue: '#00d4ff',
  neonPurple: '#a855f7',
  neonCyan: '#06b6d4',
  neonPink: '#ec4899',
  neonGreen: '#10b981',
  
  // Rank colors (more vibrant)
  rankE: '#78716c',
  rankD: '#64748b',
  rankC: '#10b981',
  rankB: '#3b82f6',
  rankA: '#a855f7',
  rankS: '#f59e0b',
  rankSPlus: '#ef4444',
  
  // Stat colors (neon variants)
  str: '#ef4444',
  agi: '#10b981',
  int: '#3b82f6',
  sta: '#f59e0b',
  per: '#a855f7',
  mag: '#8b5cf6',
  
  // Orb colors
  orbCore: '#000000',
  orbGlow: '#3b82f6',
  orbParticle: '#00d4ff',
};

export const buttonStyles = StyleSheet.create({
  primary: {
    backgroundColor: colors.primary,
    alignSelf: 'center',
    width: '100%',
  },
  secondary: {
    backgroundColor: colors.secondary,
    alignSelf: 'center',
    width: '100%',
  },
  accent: {
    backgroundColor: colors.accent,
    alignSelf: 'center',
    width: '100%',
  },
});

export const commonStyles = StyleSheet.create({
  wrapper: {
    backgroundColor: colors.background,
    width: '100%',
    height: '100%',
  },
  container: {
    flex: 1,
    backgroundColor: colors.background,
    width: '100%',
    height: '100%',
  },
  content: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    maxWidth: 800,
    width: '100%',
  },
  title: {
    fontSize: 24,
    fontWeight: '800',
    textAlign: 'center',
    color: colors.text,
    marginBottom: 10
  },
  text: {
    fontSize: 16,
    fontWeight: '500',
    color: colors.text,
    marginBottom: 8,
    lineHeight: 24,
    textAlign: 'center',
  },
  section: {
    width: '100%',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  buttonContainer: {
    width: '100%',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  card: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    marginVertical: 8,
    width: '100%',
    boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.1)',
    elevation: 3,
  },
  icon: {
    width: 60,
    height: 60,
    tintColor: colors.primary,
  },
});
